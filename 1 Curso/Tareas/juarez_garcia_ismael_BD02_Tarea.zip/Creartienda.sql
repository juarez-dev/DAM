CREATE TABLE FAMILIA --contiene las familas a las que pertenecen los productos
(
	Codfamilia NUMBER(3) PRIMARY KEY,--Codigo que distingue una familia de otra
	Denofamilia VARCHAR(50) UNIQUE --Denominacion de la familia
);

CREATE TABLE PRODUCTO --contendra informacion general sobre los productos que distribuye la empresa e las tiendas
(
	Codproducto NUMBER(5) PRIMARY KEY, --Codigo que distingue un producto de otro
	Denoproducto VARCHAR(20) NOT NULL, --Denominacion del producto
	Descripcion VARCHAR(100), --Descripcion del producto
	PrecioBase NUMBER(8,2) NOT NULL CHECK(PrecioBase>0), --Precio base del producto
	ProcReposicion NUMBER(3) CHECK(ProcReposicion>0), --Porcentaje de reposicion aplicado a ese producto. Se utilizara para aplicar a las unidades minimas y obtener el numero total de unidades a reponer cuando el stock este bajo minimo
	UnidadesMinimas NUMBER(4) NOT NULL CHECK(UnidadesMinimas>0), --Unidades minimas recomendables en almacen
	Codfamilia NUMBER(3) NOT NULL --Codigo de la familia que pertenece el producto
	CONSTRAINT Codfamilia
	REFERENCES FAMILIA(codfamilia)
);

CREATE TABLE TIENDA --contendra informacion basica sobre las tiendas que distribuyen los productos
(	
	Codtienda NUMBER(3) PRIMARY KEY, --Codigo que distingue una tienda de otra
	Denotiendea VARCHAR(20) NOT NULL, --Denominacion o nombre de la tienda
	Telefono VARCHAR(11), --Telefono de la tienda
	CodigoPostal VARCHAR(5) NOT NULL, --Codigo postal donde se ubica la tienda
	Provincia VARCHAR(5) NOT NULL --Provincia donde se ubica la tienda
);

CREATE TABLE STOCK --Contendra para cada tienda el numero de unidades disponibles de cada producto.La clave primaria esta formada por la concatenacion de los campos Coctienda y Codproducto
(
	Codtienda NUMBER(3)
	CONSTRAINT Codtienda
	REFERENCES TIENDA(Codtienda), --Codigo de la tienda
	Codproducto NUMBER(5)
	CONSTRAINT Codproducto
	REFERENCES PRODUCTO(Codproducto), --Codigo del producto
	Unidades NUMBER(5) NOT NULL CHECK(Unidades>0), --Unidades de este producto en esa tienda
	CONSTRAINT Stock_PK PRIMARY KEY (Codtienda, Codproducto)
);

